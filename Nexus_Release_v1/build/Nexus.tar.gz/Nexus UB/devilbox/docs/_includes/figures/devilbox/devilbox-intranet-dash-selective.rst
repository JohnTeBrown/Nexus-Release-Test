.. figure:: /_includes/figures/devilbox/devilbox-intranet-dash-selective.png

   Devilbox intranet: index dash view for some started container
