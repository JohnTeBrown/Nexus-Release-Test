.. |ext_lnk_download_git_win| raw:: html

   <a target="_blank" href="https://git-scm.com/download/win">
     Download Git for Windows <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>
