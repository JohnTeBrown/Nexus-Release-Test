.. figure:: /_includes/figures/https/https-ssl-address-bar.png

   Valid HTTPS will automatically be available for all projects
