.. figure:: /_includes/figures/examples/processwire/04-compat-check.png
   :width: 600px

   ProcessWire installation: Compatibility Check
