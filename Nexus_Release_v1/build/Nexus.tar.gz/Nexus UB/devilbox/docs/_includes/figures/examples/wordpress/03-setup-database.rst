.. figure:: /_includes/figures/examples/wordpress/03-setup-database.png

   Wordpress installation: Setup database
