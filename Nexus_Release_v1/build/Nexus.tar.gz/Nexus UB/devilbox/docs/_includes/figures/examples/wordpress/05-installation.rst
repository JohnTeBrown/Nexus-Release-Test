.. figure:: /_includes/figures/examples/wordpress/05-installation.png

   Wordpress installation: Installation
