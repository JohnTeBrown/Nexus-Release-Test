.. |ext_lnk_docker_image_cockroach| raw:: html

   <a target="_blank" href="https://hub.docker.com/r/cockroachdb/cockroach/">
     Cockroachc DB <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_docker_image_grafana| raw:: html

   <a target="_blank" href="https://hub.docker.com/r/grafana/grafana/">
     Grafana <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_docker_image_postgres| raw:: html

   <a target="_blank" href="https://hub.docker.com/_/postgres/">
     PostgreSQL <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_docker_image_redis| raw:: html

   <a target="_blank" href="https://hub.docker.com/_/redis/">
     Redis <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_docker_image_memcached| raw:: html

   <a target="_blank" href="https://hub.docker.com/_/memcached/">
     Memcached <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_docker_image_mongodb| raw:: html

   <a target="_blank" href="https://hub.docker.com/_/mongo/">
     MongoDB <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>
