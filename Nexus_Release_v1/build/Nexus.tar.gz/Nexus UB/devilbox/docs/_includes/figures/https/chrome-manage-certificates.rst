.. figure:: /_includes/figures/https/chrome-manage-certificates.png

   Click on ``IMPORT`` in the AUTHORITIES tab
