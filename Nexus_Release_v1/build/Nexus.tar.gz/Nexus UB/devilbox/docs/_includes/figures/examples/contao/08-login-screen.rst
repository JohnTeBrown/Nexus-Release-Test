.. figure:: /_includes/figures/examples/contao/08-login-screen.png
   :width: 400px

   Contao installation: Go to login screen
