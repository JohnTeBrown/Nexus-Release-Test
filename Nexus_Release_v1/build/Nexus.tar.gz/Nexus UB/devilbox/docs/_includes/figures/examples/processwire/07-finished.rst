.. figure:: /_includes/figures/examples/processwire/07-finished.png
   :width: 600px

   ProcessWire installation: Setup completed
