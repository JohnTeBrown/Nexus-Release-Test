.. |ext_lnk_prereq_docker_lin| raw:: html

   <a target="_blank" href="https://docs.docker.com/install/#server">
     Docker <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_prereq_docker_mac| raw:: html

   <a target="_blank" href="https://docs.docker.com/docker-for-mac/install/">
     Docker for Mac <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_prereq_docker_mac_tb| raw:: html

   <a target="_blank" href="https://docs.docker.com/toolbox/toolbox_install_mac/">
     Docker Toolbox <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_prereq_docker_win| raw:: html

   <a target="_blank" href="https://docs.docker.com/docker-for-windows/install/">
     Docker for Windows <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_prereq_docker_win_tb| raw:: html

   <a target="_blank" href="https://docs.docker.com/toolbox/toolbox_install_windows/">
     Docker Toolbox <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_prereq_docker_win_ee| raw:: html

   <a target="_blank" href="https://www.docker.com/products/orchestration">
     Docker EE <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>
