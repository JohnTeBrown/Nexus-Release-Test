.. figure:: /_includes/figures/devilbox/devilbox-project-missing-index.png

   Devilbox project: misssing ``index.php`` or ``index.html``
