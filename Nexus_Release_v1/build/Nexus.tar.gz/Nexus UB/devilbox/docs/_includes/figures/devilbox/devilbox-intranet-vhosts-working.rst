.. figure:: /_includes/figures/devilbox/devilbox-intranet-vhosts-working.png

   Devilbox intranet: vhost setup successfully
