.. figure:: /_includes/figures/dns-server/android/android-wifi-select-dhcp-options-static.jpg
   :width: 250px

   Android: Select static DHCP options
