.. figure:: /_includes/figures/dns-server/android/android-wifi-select-dhcp-options.jpg
   :width: 250px

   Android: Select DHCP options
