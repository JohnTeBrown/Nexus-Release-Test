# Devilbox base configuration

Those folders include the devilbox base configuration.

Do not edit anything here!

You can use the `cfg/` directory in the root folder to customize your configuration.
