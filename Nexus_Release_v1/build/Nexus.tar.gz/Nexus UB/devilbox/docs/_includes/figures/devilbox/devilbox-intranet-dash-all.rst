.. figure:: /_includes/figures/devilbox/devilbox-intranet-dash-all.png

   Devilbox intranet: index dash view for all started container
