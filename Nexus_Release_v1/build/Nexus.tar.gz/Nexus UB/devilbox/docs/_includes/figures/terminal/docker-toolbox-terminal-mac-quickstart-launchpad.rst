.. figure:: /_includes/figures/terminal/docker-toolbox-terminal-mac-quickstart-launchpad.png

   Copyright docs.docker.com
