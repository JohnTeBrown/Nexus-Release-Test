.. figure:: /_includes/figures/examples/wordpress/04-finished-database.png

   Wordpress installation: Database setup finished
