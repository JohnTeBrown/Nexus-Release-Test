.. figure:: /_includes/figures/https/chrome-advanced-settings.png

   Click on ``Manage certificates``
