.. |ext_lnk_ssh_tunnelling_for_fun_and_profit| raw:: html

   <a target="_blank" href="https://www.everythingcli.org/ssh-tunnelling-for-fun-and-profit-local-vs-remote/">
     SSH tunnelling for fun and profie: Local vs Remote <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>


.. |ext_lnk_stackoverflow_ssh_into_docker_machine| raw:: html

   <a target="_blank" href="https://stackoverflow.com/questions/30330442/how-to-ssh-into-docker-machine-virtualbox-instance">
     Stackoverflow: SSH into Docker machine <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>
