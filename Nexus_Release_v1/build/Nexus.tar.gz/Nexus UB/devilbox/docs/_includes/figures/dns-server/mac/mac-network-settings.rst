.. figure:: /_includes/figures/dns-server/mac/mac-network-settings.png

   MacOS: network settings
