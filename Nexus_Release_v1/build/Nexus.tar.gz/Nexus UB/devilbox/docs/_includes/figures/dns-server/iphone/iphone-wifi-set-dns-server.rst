.. figure:: /_includes/figures/dns-server/iphone/iphone-wifi-set-dns-server.jpg
   :width: 250px

   iPhone: Wi-Fi list
