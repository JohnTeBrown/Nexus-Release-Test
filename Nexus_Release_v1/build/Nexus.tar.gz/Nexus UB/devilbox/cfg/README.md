# Devilbox user-defined settings

Use this folders to add general custom configuration.
