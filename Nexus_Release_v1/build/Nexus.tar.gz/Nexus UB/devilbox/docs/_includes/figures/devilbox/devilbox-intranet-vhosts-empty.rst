.. figure:: /_includes/figures/devilbox/devilbox-intranet-vhosts-empty.png

   Devilbox intranet: no projects created
