.. figure:: /_includes/figures/devilbox/devilbox-project-hello-world.png

   Devilbox project: hello world on ``index.php``
