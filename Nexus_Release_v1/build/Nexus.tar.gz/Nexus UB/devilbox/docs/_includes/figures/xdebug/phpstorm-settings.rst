.. figure:: /_includes/figures/xdebug/phpstorm-settings.png

   PHPStorm settings: Xdebug
