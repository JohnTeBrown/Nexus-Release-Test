.. figure:: /_includes/figures/examples/contao/07-finished.png
   :width: 400px

   Contao installation: Installation successfully finished
