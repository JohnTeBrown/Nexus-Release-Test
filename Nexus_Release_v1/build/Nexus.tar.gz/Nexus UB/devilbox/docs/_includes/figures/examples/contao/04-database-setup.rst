.. figure:: /_includes/figures/examples/contao/04-database-setup.png
   :width: 400px

   Contao installation: Database setup
