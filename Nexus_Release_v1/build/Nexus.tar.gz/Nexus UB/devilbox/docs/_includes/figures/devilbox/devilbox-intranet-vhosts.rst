.. figure:: /_includes/figures/devilbox/devilbox-intranet-vhosts.png

   Devilbox intranet: available virtual hosts
