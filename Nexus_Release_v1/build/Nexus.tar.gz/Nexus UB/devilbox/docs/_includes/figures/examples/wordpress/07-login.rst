.. figure:: /_includes/figures/examples/wordpress/07-login.png
   :width: 300px

   Wordpress installation: Login
