.. figure:: /_includes/figures/https/firefox-preferences.png

   Click on ``Privacy & Security`` in the left menu bar
