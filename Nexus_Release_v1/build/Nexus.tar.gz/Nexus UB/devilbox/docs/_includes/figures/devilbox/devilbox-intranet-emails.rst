.. figure:: /_includes/figures/devilbox/devilbox-intranet-emails.png

   Devilbox intranet: email catch-all overview
