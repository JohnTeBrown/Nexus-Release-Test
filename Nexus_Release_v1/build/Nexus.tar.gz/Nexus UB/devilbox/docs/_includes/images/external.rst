.. |img_logo_lin| image:: https://raw.githubusercontent.com/cytopia/icons/master/64x64/linux.png
.. |img_logo_mac| image:: https://raw.githubusercontent.com/cytopia/icons/master/64x64/osx.png
.. |img_logo_win| image:: https://raw.githubusercontent.com/cytopia/icons/master/64x64/windows.png

.. |img_banner| image:: /img/banner.png
