.. figure:: /_includes/figures/examples/wordpress/06-finished-installation.png

   Wordpress installation: Installation finished
