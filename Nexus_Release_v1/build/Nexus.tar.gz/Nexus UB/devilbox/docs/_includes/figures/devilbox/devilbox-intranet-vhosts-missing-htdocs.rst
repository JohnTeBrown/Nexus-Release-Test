.. figure:: /_includes/figures/devilbox/devilbox-intranet-vhosts-missing-htdocs.png

   Devilbox intranet: misssing ``htdocs`` directory
