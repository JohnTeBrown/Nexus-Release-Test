.. figure:: /_includes/figures/dns-server/android/android-wifi-set-dns-server.jpg
   :width: 250px

   Android: Add custom DNS server
