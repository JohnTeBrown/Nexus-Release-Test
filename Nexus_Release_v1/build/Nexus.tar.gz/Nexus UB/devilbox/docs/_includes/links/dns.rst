.. |ext_lnk_dns_archlinux_wiki_resolv_conf| raw:: html

   <a target="_blank" href="https://wiki.archlinux.org/index.php/Dhcpcd#resolv.conf">
     Archlinux Wiki: resolv.conf <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_wikipedia_cname| raw:: html

   <a target="_blank" href="https://en.wikipedia.org/wiki/CNAME_record">
     CNAME <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_domain_dev| raw:: html

   <a target="_blank" href="https://icannwiki.org/.dev">
     Google (ICANN) <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_domain_rfc_localhost| raw:: html

   <a target="_blank" href="https://tools.ietf.org/html/draft-west-let-localhost-be-localhost-06">
     RFC Draft: localhost <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_domain_docker_rel_notes_localhost| raw:: html

   <a target="_blank" href="https://docs.docker.com/docker-for-mac/release-notes/#docker-community-edition-17120-ce-mac46-2018-01-09">
     Docker Release notes: 17.12.0-ce-mac46 <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>
