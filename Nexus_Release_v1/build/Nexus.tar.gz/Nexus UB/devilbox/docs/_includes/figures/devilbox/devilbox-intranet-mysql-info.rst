.. figure:: /_includes/figures/devilbox/devilbox-intranet-mysql-info.png

   Devilbox intranet: MySQL info overview
