.. figure:: /_includes/figures/terminal/docker-toolbox-terminal-win-quickstart-shortcut.png

   Copyright docs.docker.com
