.. |ext_lnk_app_android_dns_changer| raw:: html

   <a target="_blank" href="https://play.google.com/store/apps/details?id=com.burakgon.dnschanger">
     DNS Changer <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_app_iphone_dns_override| raw:: html

   <a target="_blank" href="https://www.dnsoverride.com">
     DNS Override <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

