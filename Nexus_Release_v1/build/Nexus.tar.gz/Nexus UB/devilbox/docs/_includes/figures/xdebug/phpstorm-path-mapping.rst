.. figure:: /_includes/figures/xdebug/phpstorm-path-mapping.png

   PHPStorm settings: path mapping
