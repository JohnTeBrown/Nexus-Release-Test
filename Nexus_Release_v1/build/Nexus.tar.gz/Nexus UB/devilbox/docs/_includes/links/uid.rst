.. |ext_lnk_uid| raw:: html

   <a target="_blank" href="https://en.wikipedia.org/wiki/User_identifier">
     Wikipedia: uid <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>
