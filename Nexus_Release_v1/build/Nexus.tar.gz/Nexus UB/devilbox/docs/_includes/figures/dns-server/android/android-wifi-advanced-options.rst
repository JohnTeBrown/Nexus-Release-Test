.. figure:: /_includes/figures/dns-server/android/android-wifi-advanced-options.jpg
   :width: 250px

   Android: Advanced options
