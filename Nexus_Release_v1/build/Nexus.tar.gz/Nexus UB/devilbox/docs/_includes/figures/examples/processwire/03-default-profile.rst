.. figure:: /_includes/figures/examples/processwire/03-default-profile.png
   :width: 600px

   ProcessWire installation: Choose Default Profile
