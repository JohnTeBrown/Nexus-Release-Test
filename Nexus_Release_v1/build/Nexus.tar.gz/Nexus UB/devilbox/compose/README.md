# Docker Compose overwrites

This directory container various `docker-compose.override.yml` examples to be used with the Devilbox.

Note that those override files have their own environment variables that should be **appended** to `.env`
