.. figure:: /_includes/figures/devilbox/devilbox-intranet-php-info.png

   Devilbox intranet: php info
