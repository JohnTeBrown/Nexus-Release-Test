.. |ext_lnk_blog_openstream| raw:: html

   <a target="_blank" href="https://www.openstream.ch/developer-blog/devilbox/">
     Docker LAMP Stack for WordPress and Magento <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_blog_deliciousbrains| raw:: html

   <a target="_blank" href="https://deliciousbrains.com/devilbox-local-wordpress-development-docker/">
     Using Devilbox For Local WordPress Development In Docker <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_blog_joomla_pr_testing_platform| raw:: html

   <a target="_blank" href="https://docs.joomla.org/PR_Testing_Platform">
     PR Testing Platform <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_blog_joomla_gsoc2017| raw:: html

   <a target="_blank" href="https://docs.joomla.org/GSOC_2017">
     Google Summer of Code 2017 <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_blog_drupalcamp_ghent_2018_slides| raw:: html

   <a target="_blank" href="https://docs.google.com/presentation/d/1MvSwPlFL3TozWBtwpfNUTKVOvTbYzRY6GBQ9v2VS_GA/edit#slide=id.g45ef3f2bc6_2_54">
     Drupalcamp Ghent 2018: Slides <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>

.. |ext_lnk_blog_drupalcamp_ghent_2018_presentation| raw:: html

   <a target="_blank" href="https://www.youtube.com/watch?v=88Sr0aNvVm0">
     Drupalcamp Ghent 2018: Presentation <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" />
   </a>
