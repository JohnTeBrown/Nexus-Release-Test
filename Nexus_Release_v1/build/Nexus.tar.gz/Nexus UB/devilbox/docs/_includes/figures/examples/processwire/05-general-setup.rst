.. figure:: /_includes/figures/examples/processwire/05-general-setup.png
   :width: 600px

   ProcessWire installation: General Setup
