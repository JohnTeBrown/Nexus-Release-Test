.. figure:: /_includes/figures/https/file-manager-import-ca.png

   **Note**: your file manager might look different
