.. figure:: /_includes/figures/dns-server/iphone/iphone-wifi-list.jpg
   :width: 250px

   iPhone: Wi-Fi list
