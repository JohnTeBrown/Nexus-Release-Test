.. figure:: /_includes/figures/blogs/youtube-email-catch-all.png
   :target: https://www.youtube.com/watch?v=e-U-C5WhxGY
