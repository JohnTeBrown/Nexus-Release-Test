.. figure:: /_includes/figures/https/chrome-settings.png

   Click on ``Advanced``
