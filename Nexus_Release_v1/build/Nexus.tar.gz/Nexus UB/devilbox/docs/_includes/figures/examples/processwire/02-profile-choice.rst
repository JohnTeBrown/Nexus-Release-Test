.. figure:: /_includes/figures/examples/processwire/02-profile-choice.png
   :width: 600px

   ProcessWire installation: Profile Choice
