.. figure:: /_includes/figures/https/firefox-set-trust.png

   Tell Firefox to trust this CA
