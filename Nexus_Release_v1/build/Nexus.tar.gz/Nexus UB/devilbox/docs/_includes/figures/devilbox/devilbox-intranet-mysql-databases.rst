.. figure:: /_includes/figures/devilbox/devilbox-intranet-mysql-databases.png

   Devilbox intranet: MySQL database overview
