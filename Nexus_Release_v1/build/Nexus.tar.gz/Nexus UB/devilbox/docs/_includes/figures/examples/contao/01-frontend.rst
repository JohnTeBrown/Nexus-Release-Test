.. figure:: /_includes/figures/examples/contao/01-frontend.png
   :width: 400px

   Contao installation: Installation incomplete note
