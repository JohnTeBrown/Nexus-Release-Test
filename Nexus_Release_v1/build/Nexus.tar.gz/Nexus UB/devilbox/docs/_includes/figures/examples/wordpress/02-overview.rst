.. figure:: /_includes/figures/examples/wordpress/02-overview.png

   Wordpress installation: Overview
