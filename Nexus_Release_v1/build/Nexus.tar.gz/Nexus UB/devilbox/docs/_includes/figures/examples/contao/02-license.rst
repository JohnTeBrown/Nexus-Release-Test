.. figure:: /_includes/figures/examples/contao/02-license.png
   :width: 400px

   Contao installation: Accept license
