.. figure:: /_includes/figures/devilbox/devilbox-intranet-vhosts-missing-dns.png

   Devilbox intranet: misssing dns record
