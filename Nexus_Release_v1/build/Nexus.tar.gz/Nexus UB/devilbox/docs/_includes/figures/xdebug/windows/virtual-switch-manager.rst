.. figure:: /_includes/figures/xdebug/windows/virtual-switch-manager.png

   Windows: Virtual Switch Manager example screenshot
