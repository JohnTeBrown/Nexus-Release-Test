.. figure:: /_includes/figures/https/firefox-certificate-manager.png

   Click on ``Import`` in the Authorities tab
