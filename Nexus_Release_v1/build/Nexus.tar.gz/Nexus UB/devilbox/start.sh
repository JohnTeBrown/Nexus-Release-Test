#!/bin/bash

echo "==================="
echo "Starting DevilBox"
echo "==================="


sudo docker-compose up