.. figure:: /_includes/figures/terminal/docker-toolbox-terminal-win-quickstart-terminal.png

   Copyright docs.docker.com
