.. figure:: /_includes/figures/dns-server/windows/win-ethernet-properties.png

   Windows: ethernet properties
