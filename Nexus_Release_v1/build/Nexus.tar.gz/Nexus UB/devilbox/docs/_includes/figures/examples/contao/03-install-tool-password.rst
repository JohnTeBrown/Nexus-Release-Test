.. figure:: /_includes/figures/examples/contao/03-install-tool-password.png
   :width: 400px

   Contao installation: Set install tool password
