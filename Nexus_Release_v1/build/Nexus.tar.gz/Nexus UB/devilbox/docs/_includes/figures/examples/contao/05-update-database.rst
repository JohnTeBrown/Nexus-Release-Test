.. figure:: /_includes/figures/examples/contao/05-update-database.png
   :width: 400px

   Contao installation: Update database
