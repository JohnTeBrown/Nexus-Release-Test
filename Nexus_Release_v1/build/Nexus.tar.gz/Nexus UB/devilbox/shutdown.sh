#!/bin/bash

echo "==================="
echo "Shutting Down. . ."
echo "==================="


sudo docker-compose stop