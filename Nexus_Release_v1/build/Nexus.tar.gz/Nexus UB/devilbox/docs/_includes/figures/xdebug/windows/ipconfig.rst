.. figure:: /_includes/figures/xdebug/windows/ipconfig.png

   Windows: ipconfig example output
