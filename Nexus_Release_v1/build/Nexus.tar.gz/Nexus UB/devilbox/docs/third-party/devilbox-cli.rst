.. include:: /_includes/snippets/__ANNOUNCEMENTS__.rst

************
Devilbox CLI
************


Project goal
============

``devilbox-cli.sh`` is a simple and conveniant bash script. It consists of multiple grep and sed
in order to easily change the ``.env`` configuration of devilbox and also a shorthand to start the
containers. It has been validated with shellcheck.


Project details
===============

* **Project:** https://github.com/louisgab/devilbox-cli
* **Mirror:** https://github.com/devilbox/devilbox-cli
