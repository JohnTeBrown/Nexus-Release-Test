.. figure:: /_includes/figures/examples/wordpress/01-choose-language.png
   :width: 400px

   Wordpress installation: Choose language
