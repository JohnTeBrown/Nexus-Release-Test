.. figure:: /_includes/figures/examples/processwire/01-install-banner.png
   :width: 600px

   ProcessWire installation: Overview
