.. figure:: /_includes/figures/https/firefox-privacy-and-security.png

   Click on ``View Certificates``
