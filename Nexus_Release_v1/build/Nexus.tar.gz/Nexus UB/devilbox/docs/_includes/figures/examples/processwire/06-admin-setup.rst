.. figure:: /_includes/figures/examples/processwire/06-admin-setup.png
   :width: 600px

   ProcessWire installation: Admin Setup
