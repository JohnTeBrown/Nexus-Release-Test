.. figure:: /_includes/figures/devilbox/devilbox-intranet-index.png

   Devilbox intranet: homepage
