.. |ext_lnk_devilbox_pr_announce| raw:: html

   <a target="_blank" href="https://github.com/cytopia/devilbox/pull/942">
     <strong>Release v3.0.0-beta-0.1 <img src="https://raw.githubusercontent.com/cytopia/icons/master/11x11/ext-link.png" /></strong>
   </a>



.. attention::

    You can now run different PHP versions per project: |ext_lnk_devilbox_pr_announce|
