.. figure:: /_includes/figures/dns-server/windows/win-network-connections.png

   Windows: network connections
