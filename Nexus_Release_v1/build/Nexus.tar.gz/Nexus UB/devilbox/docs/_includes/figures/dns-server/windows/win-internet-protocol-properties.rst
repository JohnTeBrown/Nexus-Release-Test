.. figure:: /_includes/figures/dns-server/windows/win-internet-protocol-properties.png

   Windows: internet protocol properties
