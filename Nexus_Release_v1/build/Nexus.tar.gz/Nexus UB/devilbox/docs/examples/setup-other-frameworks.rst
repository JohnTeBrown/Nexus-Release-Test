.. include:: /_includes/snippets/__ANNOUNCEMENTS__.rst

.. _example_setup_other_frameworks:

**********************
Setup other Frameworks
**********************

The setup instructions and frameworks shown in this section are only meant as an example
and the list is in no way complete.

The Devilbox itself is a normal development stack and is capable of running *any* framework, CMS
or custom written PHP software.

If you wish to see more install guides, open up an issue at Github: https://github.com/cytopia/devilbox/issues
