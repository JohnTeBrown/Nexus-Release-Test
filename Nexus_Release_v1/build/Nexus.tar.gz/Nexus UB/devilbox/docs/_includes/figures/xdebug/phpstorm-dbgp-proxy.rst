.. figure:: /_includes/figures/xdebug/phpstorm-dbgp-proxy.png

   PHPStorm settings: DBGp Proxy
