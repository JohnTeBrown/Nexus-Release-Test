.. figure:: /_includes/figures/blogs/youtube-setup-and-workflow.png
   :target: https://www.youtube.com/watch?v=reyZMyt2Zzo
