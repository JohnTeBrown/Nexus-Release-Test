.. figure:: /_includes/figures/https/chrome-set-trust.png

   Tell Chrome to trust this CA
