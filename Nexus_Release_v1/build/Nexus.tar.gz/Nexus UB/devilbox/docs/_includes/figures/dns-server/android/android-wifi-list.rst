.. figure:: /_includes/figures/dns-server/android/android-wifi-list.jpg
   :width: 250px

   Android: Wi-Fi list
